#include <map>
#include <string>
#include "proj0.hpp"


bool verifySolution(std::string s1, std::string s2, std::string s3, const std::map<char, unsigned> & mapping) {
    std::string stringVals[3] = {"", "", ""};
    std::string strings[3] = {s1, s2, s3};
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < strings[i].length(); j++) {
            stringVals[i] += std::to_string(mapping.at(strings[i][j]));
        }
    }
    return std::stoi(stringVals[0]) + std::stoi(stringVals[1]) == std::stoi(stringVals[2]);
}





